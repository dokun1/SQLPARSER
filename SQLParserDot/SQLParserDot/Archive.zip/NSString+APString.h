//
//  NSString+APString.h
//  Afterparty
//
//  Copyright (c) 2013 DMOS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (APString)

-(BOOL)containsString:(NSString*)string;

@end
